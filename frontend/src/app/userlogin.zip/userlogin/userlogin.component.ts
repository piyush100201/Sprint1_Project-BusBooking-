import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthServiceService } from '../auth-service.service';

@Component({
  selector: 'app-userlogin',
  templateUrl: './userlogin.component.html',
  styleUrls: ['./userlogin.component.css']
})
export class UserloginComponent implements OnInit {

  submitted = false;
  loginForm!: FormGroup; //this represents whole form
  email!: FormControl;
  password!: FormControl;

  constructor(public authService: AuthServiceService, public router: Router) {}

  ngOnInit(): void {
    this.email = new FormControl('', [Validators.required]);
    this.password = new FormControl('', [Validators.required]);

    this.loginForm = new FormGroup({
      'email': this.email,
      'password': this.password
    })
  }

  loginUser() {
    this.authService.login(this.loginForm.value)
  }
  }




  
  
 
      
